{{/*
Expand the name of the chart.
*/}}
{{- define "evolution-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "evolution-api.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "evolution-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "evolution-api.labels" -}}
helm.sh/chart: {{ include "evolution-api.chart" . }}
{{ include "evolution-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "evolution-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "evolution-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "evolution-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "evolution-api.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
API component labels
*/}}
{{- define "evolution-api.api.labels" -}}
{{ include "evolution-api.labels" . }}
app.kubernetes.io/component: api
{{- end }}

{{/*
API selector labels
*/}}
{{- define "evolution-api.api.selectorLabels" -}}
{{ include "evolution-api.selectorLabels" . }}
app.kubernetes.io/component: api
{{- end }}

{{/*
Manager component labels
*/}}
{{- define "evolution-api.manager.labels" -}}
{{ include "evolution-api.labels" . }}
app.kubernetes.io/component: manager
{{- end }}

{{/*
Manager selector labels
*/}}
{{- define "evolution-api.manager.selectorLabels" -}}
{{ include "evolution-api.selectorLabels" . }}
app.kubernetes.io/component: manager
{{- end }}

{{/*
PostgreSQL hostname
*/}}
{{- define "evolution-api.postgresql.host" -}}
{{- if .Values.postgresqlOperator.enabled }}
{{- /* CloudNative-PG creates service named <cluster>-rw for read-write */ -}}
{{- printf "%s-postgresql-rw" (include "evolution-api.fullname" .) }}
{{- else if .Values.postgresql.enabled }}
{{- printf "%s-postgresql" (include "evolution-api.fullname" .) }}
{{- else if .Values.postgresqlStandalone.enabled }}
{{- printf "%s-postgresql" (include "evolution-api.fullname" .) }}
{{- else }}
{{- .Values.externalPostgresql.host }}
{{- end }}
{{- end }}

{{/*
PostgreSQL port
*/}}
{{- define "evolution-api.postgresql.port" -}}
{{- if or .Values.postgresqlOperator.enabled .Values.postgresql.enabled .Values.postgresqlStandalone.enabled }}
{{- printf "5432" }}
{{- else }}
{{- .Values.externalPostgresql.port | toString }}
{{- end }}
{{- end }}

{{/*
PostgreSQL database name
*/}}
{{- define "evolution-api.postgresql.database" -}}
{{- if .Values.postgresqlOperator.enabled }}
{{- .Values.postgresqlOperator.auth.database | default "evolution" }}
{{- else if .Values.postgresql.enabled }}
{{- .Values.postgresql.auth.database }}
{{- else if .Values.postgresqlStandalone.enabled }}
{{- .Values.postgresqlStandalone.auth.database }}
{{- else }}
{{- .Values.externalPostgresql.database }}
{{- end }}
{{- end }}

{{/*
PostgreSQL username
*/}}
{{- define "evolution-api.postgresql.username" -}}
{{- if .Values.postgresqlOperator.enabled }}
{{- .Values.postgresqlOperator.auth.username | default "evolution" }}
{{- else if .Values.postgresql.enabled }}
{{- .Values.postgresql.auth.username }}
{{- else if .Values.postgresqlStandalone.enabled }}
{{- .Values.postgresqlStandalone.auth.username }}
{{- else }}
{{- .Values.externalPostgresql.username }}
{{- end }}
{{- end }}

{{/*
PostgreSQL password secret name
*/}}
{{- define "evolution-api.postgresql.secretName" -}}
{{- if .Values.postgresqlOperator.enabled }}
{{- /* We use our own credentials secret, not the one CNPG creates */ -}}
{{- printf "%s-postgresql-credentials" (include "evolution-api.fullname" .) }}
{{- else if .Values.postgresql.enabled }}
{{- printf "%s-postgresql" (include "evolution-api.fullname" .) }}
{{- else if .Values.postgresqlStandalone.enabled }}
{{- printf "%s-postgresql" (include "evolution-api.fullname" .) }}
{{- else if .Values.externalPostgresql.existingSecret }}
{{- .Values.externalPostgresql.existingSecret }}
{{- else }}
{{- printf "%s-external-postgresql" (include "evolution-api.fullname" .) }}
{{- end }}
{{- end }}

{{/*
PostgreSQL password secret key
*/}}
{{- define "evolution-api.postgresql.secretKey" -}}
{{- if .Values.postgresqlOperator.enabled }}
{{- printf "password" }}
{{- else if .Values.postgresql.enabled }}
{{- printf "password" }}
{{- else if .Values.externalPostgresql.existingSecretPasswordKey }}
{{- .Values.externalPostgresql.existingSecretPasswordKey }}
{{- else }}
{{- printf "password" }}
{{- end }}
{{- end }}

{{/*
PostgreSQL connection URI
*/}}
{{- define "evolution-api.postgresql.uri" -}}
{{- $host := include "evolution-api.postgresql.host" . -}}
{{- $port := include "evolution-api.postgresql.port" . -}}
{{- $database := include "evolution-api.postgresql.database" . -}}
{{- $username := include "evolution-api.postgresql.username" . -}}
{{- printf "postgresql://%s:$(DATABASE_PASSWORD)@%s:%s/%s" $username $host $port $database }}
{{- end }}

{{/*
Redis hostname
*/}}
{{- define "evolution-api.redis.host" -}}
{{- if .Values.redis.enabled }}
{{- printf "%s-redis-master" (include "evolution-api.fullname" .) }}
{{- else }}
{{- .Values.externalRedis.host }}
{{- end }}
{{- end }}

{{/*
Redis port
*/}}
{{- define "evolution-api.redis.port" -}}
{{- if .Values.redis.enabled }}
{{- printf "6379" }}
{{- else }}
{{- .Values.externalRedis.port | toString }}
{{- end }}
{{- end }}

{{/*
Redis database
*/}}
{{- define "evolution-api.redis.database" -}}
{{- if .Values.redis.enabled }}
{{- printf "0" }}
{{- else }}
{{- .Values.externalRedis.database | toString }}
{{- end }}
{{- end }}

{{/*
Redis URI
*/}}
{{- define "evolution-api.redis.uri" -}}
{{- $host := include "evolution-api.redis.host" . -}}
{{- $port := include "evolution-api.redis.port" . -}}
{{- $database := include "evolution-api.redis.database" . -}}
{{- if .Values.redis.enabled }}
  {{- if .Values.redis.auth.enabled }}
    {{- printf "redis://:%s@%s:%s/%s" "$(REDIS_PASSWORD)" $host $port $database }}
  {{- else }}
    {{- printf "redis://%s:%s/%s" $host $port $database }}
  {{- end }}
{{- else }}
  {{- if or .Values.externalRedis.password .Values.externalRedis.existingSecret }}
    {{- printf "redis://:%s@%s:%s/%s" "$(REDIS_PASSWORD)" $host $port $database }}
  {{- else }}
    {{- printf "redis://%s:%s/%s" $host $port $database }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Redis password secret name
*/}}
{{- define "evolution-api.redis.secretName" -}}
{{- if .Values.redis.enabled }}
{{- printf "%s-redis" (include "evolution-api.fullname" .) }}
{{- else if .Values.externalRedis.existingSecret }}
{{- .Values.externalRedis.existingSecret }}
{{- else }}
{{- printf "%s-external-redis" (include "evolution-api.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Redis password secret key
*/}}
{{- define "evolution-api.redis.secretKey" -}}
{{- if .Values.redis.enabled }}
{{- printf "redis-password" }}
{{- else if .Values.externalRedis.existingSecretPasswordKey }}
{{- .Values.externalRedis.existingSecretPasswordKey }}
{{- else }}
{{- printf "password" }}
{{- end }}
{{- end }}

{{/*
Check if Redis requires authentication
*/}}
{{- define "evolution-api.redis.authRequired" -}}
{{- if .Values.redis.enabled }}
{{- .Values.redis.auth.enabled }}
{{- else }}
{{- or .Values.externalRedis.password .Values.externalRedis.existingSecret }}
{{- end }}
{{- end }}

{{/*
API Secret name
*/}}
{{- define "evolution-api.api.secretName" -}}
{{- if .Values.api.authentication.existingSecret }}
{{- .Values.api.authentication.existingSecret }}
{{- else }}
{{- printf "%s-api" (include "evolution-api.fullname" .) }}
{{- end }}
{{- end }}

{{/*
============================================
RabbitMQ Helpers
============================================
*/}}

{{/*
RabbitMQ hostname
*/}}
{{- define "evolution-api.rabbitmq.host" -}}
{{- if .Values.rabbitmqOperator.enabled }}
{{- printf "%s-rabbitmq" (include "evolution-api.fullname" .) }}
{{- else if .Values.rabbitmqCluster.enabled }}
{{- printf "%s-rabbitmq" (include "evolution-api.fullname" .) }}
{{- else if .Values.rabbitmqStandalone.enabled }}
{{- printf "%s-rabbitmq" (include "evolution-api.fullname" .) }}
{{- else }}
{{- .Values.externalRabbitmq.host | default "localhost" }}
{{- end }}
{{- end }}

{{/*
RabbitMQ port
*/}}
{{- define "evolution-api.rabbitmq.port" -}}
{{- if or .Values.rabbitmqOperator.enabled .Values.rabbitmqCluster.enabled .Values.rabbitmqStandalone.enabled }}
{{- printf "5672" }}
{{- else }}
{{- .Values.externalRabbitmq.port | default 5672 | toString }}
{{- end }}
{{- end }}

{{/*
RabbitMQ username (used when not using operator secret)
*/}}
{{- define "evolution-api.rabbitmq.username" -}}
{{- if .Values.rabbitmqOperator.enabled }}
{{- /* Operator generates random credentials, use $(RABBITMQ_USERNAME) placeholder */ -}}
{{- printf "$(RABBITMQ_USERNAME)" }}
{{- else if .Values.rabbitmqCluster.enabled }}
{{- .Values.rabbitmq.auth.username | default "evolution" }}
{{- else if .Values.rabbitmqStandalone.enabled }}
{{- .Values.rabbitmqStandalone.auth.username | default "evolution" }}
{{- else }}
{{- .Values.externalRabbitmq.username | default "guest" }}
{{- end }}
{{- end }}

{{/*
RabbitMQ vhost
*/}}
{{- define "evolution-api.rabbitmq.vhost" -}}
{{- if or .Values.rabbitmqOperator.enabled .Values.rabbitmqCluster.enabled .Values.rabbitmqStandalone.enabled }}
{{- "/" }}
{{- else }}
{{- .Values.externalRabbitmq.vhost | default "/" }}
{{- end }}
{{- end }}

{{/*
RabbitMQ URI
*/}}
{{- define "evolution-api.rabbitmq.uri" -}}
{{- $host := include "evolution-api.rabbitmq.host" . -}}
{{- $port := include "evolution-api.rabbitmq.port" . -}}
{{- $vhost := include "evolution-api.rabbitmq.vhost" . -}}
{{- if .Values.rabbitmqOperator.enabled }}
{{- /* Operator: use placeholders that will be replaced by env vars */ -}}
{{- printf "amqp://$(RABBITMQ_USERNAME):$(RABBITMQ_PASSWORD)@%s:%s%s" $host $port $vhost }}
{{- else if .Values.rabbitmqCluster.enabled }}
{{- $username := .Values.rabbitmq.auth.username | default "evolution" -}}
{{- printf "amqp://%s:$(RABBITMQ_PASSWORD)@%s:%s%s" $username $host $port $vhost }}
{{- else if .Values.rabbitmqStandalone.enabled }}
{{- $username := .Values.rabbitmqStandalone.auth.username | default "evolution" -}}
{{- printf "amqp://%s:$(RABBITMQ_PASSWORD)@%s:%s%s" $username $host $port $vhost }}
{{- else if or .Values.externalRabbitmq.password .Values.externalRabbitmq.existingSecret }}
{{- $username := .Values.externalRabbitmq.username | default "guest" -}}
{{- printf "amqp://%s:$(RABBITMQ_PASSWORD)@%s:%s%s" $username $host $port $vhost }}
{{- else }}
{{- $username := .Values.externalRabbitmq.username | default "guest" -}}
{{- printf "amqp://%s@%s:%s%s" $username $host $port $vhost }}
{{- end }}
{{- end }}

{{/*
RabbitMQ password secret name
*/}}
{{- define "evolution-api.rabbitmq.secretName" -}}
{{- if .Values.rabbitmqOperator.enabled }}
{{- /* Operator creates secret named <cluster-name>-default-user */ -}}
{{- printf "%s-rabbitmq-default-user" (include "evolution-api.fullname" .) }}
{{- else if .Values.rabbitmqCluster.enabled }}
{{- printf "%s-rabbitmq" (include "evolution-api.fullname" .) }}
{{- else if .Values.rabbitmqStandalone.enabled }}
{{- printf "%s-rabbitmq" (include "evolution-api.fullname" .) }}
{{- else if .Values.externalRabbitmq.existingSecret }}
{{- .Values.externalRabbitmq.existingSecret }}
{{- else }}
{{- printf "%s-external-rabbitmq" (include "evolution-api.fullname" .) }}
{{- end }}
{{- end }}

{{/*
RabbitMQ password secret key
*/}}
{{- define "evolution-api.rabbitmq.secretKey" -}}
{{- if .Values.rabbitmqOperator.enabled }}
{{- /* Operator uses 'password' as key */ -}}
{{- printf "password" }}
{{- else if .Values.rabbitmqCluster.enabled }}
{{- printf "rabbitmq-password" }}
{{- else if .Values.rabbitmqStandalone.enabled }}
{{- printf "rabbitmq-password" }}
{{- else if .Values.externalRabbitmq.existingSecretPasswordKey }}
{{- .Values.externalRabbitmq.existingSecretPasswordKey }}
{{- else }}
{{- printf "password" }}
{{- end }}
{{- end }}

{{/*
RabbitMQ username secret key (only for operator)
*/}}
{{- define "evolution-api.rabbitmq.usernameSecretKey" -}}
{{- printf "username" }}
{{- end }}

{{/*
Check if RabbitMQ uses internal deployment (any type)
*/}}
{{- define "evolution-api.rabbitmq.isInternal" -}}
{{- if or .Values.rabbitmqOperator.enabled .Values.rabbitmqCluster.enabled .Values.rabbitmqStandalone.enabled }}
{{- printf "true" }}
{{- else }}
{{- printf "false" }}
{{- end }}
{{- end }}

{{/*
============================================
Kafka Helpers
============================================
*/}}

{{/*
Kafka brokers list
*/}}
{{- define "evolution-api.kafka.brokers" -}}
{{- if .Values.kafkaCluster.enabled }}
{{- printf "%s-kafka:9092" (include "evolution-api.fullname" .) }}
{{- else }}
{{- .Values.externalKafka.brokers | default "localhost:9092" }}
{{- end }}
{{- end }}

{{/*
Kafka SASL username (if auth enabled)
*/}}
{{- define "evolution-api.kafka.username" -}}
{{- if .Values.kafkaCluster.enabled }}
{{- .Values.kafka.sasl.client.users | first | default "evolution" }}
{{- else }}
{{- .Values.externalKafka.username | default "" }}
{{- end }}
{{- end }}

{{/*
Kafka password secret name
*/}}
{{- define "evolution-api.kafka.secretName" -}}
{{- if .Values.kafkaCluster.enabled }}
{{- printf "%s-kafka-user-passwords" (include "evolution-api.fullname" .) }}
{{- else if .Values.externalKafka.existingSecret }}
{{- .Values.externalKafka.existingSecret }}
{{- else }}
{{- printf "%s-external-kafka" (include "evolution-api.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Kafka password secret key
*/}}
{{- define "evolution-api.kafka.secretKey" -}}
{{- if .Values.kafkaCluster.enabled }}
{{- printf "client-passwords" }}
{{- else if .Values.externalKafka.existingSecretPasswordKey }}
{{- .Values.externalKafka.existingSecretPasswordKey }}
{{- else }}
{{- printf "password" }}
{{- end }}
{{- end }}
